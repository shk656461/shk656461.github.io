"""Pygame front end: python -m pacman_py (also runs in the browser via pygbag)."""

import asyncio

import pygame

from .game import COLS, DOT, DOWN, LEFT, PELLET, RIGHT, ROWS, UP, Game

import os

SCALE = 3
W, H = 320, 200            # CGA mode 4 resolution used by the original
ASSETS = os.path.join(os.path.dirname(__file__), "assets")
WHITE, YELLOW, GREEN, RED = (255, 255, 255), (255, 255, 85), (85, 255, 85), (255, 85, 85)
KEYS = {
    pygame.K_UP: UP, pygame.K_w: UP, pygame.K_i: UP, pygame.K_e: UP,
    pygame.K_DOWN: DOWN, pygame.K_s: DOWN, pygame.K_j: DOWN, pygame.K_d: DOWN,
    pygame.K_LEFT: LEFT, pygame.K_a: LEFT, pygame.K_k: LEFT,
    pygame.K_RIGHT: RIGHT, pygame.K_l: RIGHT,
}

# Sprite sheet indices (16x14 px blocks decoded from the original, see tools/extract_assets.py).
# Pac-Man frames per direction: wide, narrow, closed, narrow.
PAC_FRAMES = {DOWN: (1, 2, 3, 2), UP: (0, 2, 3, 2), LEFT: (5, 6, 7, 6), RIGHT: (9, 10, 11, 10)}
GHOST_FRAMES = [(13, 14), (19, 20), (16, 17), (22, 23)]  # guessed pairing, unverified
FRIGHT_FRAMES = (25, 26)


def cell_xy(row, col):
    """Top-left pixel of a grid cell on the 320x200 screen (matches the original's blit)."""
    return 52 + 8 * col, 8 * row - 4


class Art:
    def __init__(self):
        load = lambda n: pygame.image.load(os.path.join(ASSETS, n))
        self.walls = load("walls.png")
        self.dot, self.pellet = load("dot.png"), load("pellet.png")
        sheet = load("sprites.png")
        self.sprites = []
        for i in range(64):
            s = sheet.subsurface(((i % 16) * 16, (i // 16) * 14, 16, 14)).copy()
            s.set_colorkey((0, 0, 0))
            self.sprites.append(s)
        for t in (self.dot, self.pellet):
            t.set_colorkey((0, 0, 0))


def lerp_pos(prev, cur, t):
    """Pixel position between two cells; no tween across the tunnel wrap."""
    if abs(cur[1] - prev[1]) > 1 or abs(cur[0] - prev[0]) > 1:
        t = 1
    r = prev[0] + (cur[0] - prev[0]) * t
    c = prev[1] + (cur[1] - prev[1]) * t
    return 52 + 8 * c + 4, 8 * r - 4 + 4


def draw(screen, art, font, game, prev, t, frame):
    canvas = pygame.Surface((W, H))
    canvas.blit(art.walls, (0, 0))
    for r in range(ROWS):
        for c in range(COLS):
            v = game.grid[r][c]
            if v == DOT:
                canvas.blit(art.dot, cell_xy(r, c))
            elif v == PELLET and (frame // 8) % 2 == 0:
                canvas.blit(art.pellet, cell_xy(r, c))
    p = game.pac
    cx, cy = lerp_pos(prev["pac"], (p.row, p.col), t)
    img = art.sprites[PAC_FRAMES[p.direction][(frame // 3) % 4]]
    canvas.blit(img, (round(cx) - 8, round(cy) - 7))
    for i, g in enumerate(game.ghosts):
        cx, cy = lerp_pos(prev["ghosts"][i], (g.row, g.col), t)
        if game.fright:
            if game.fright < 10 and (frame // 6) % 2:
                idx = GHOST_FRAMES[i][0]
            else:
                idx = FRIGHT_FRAMES[(frame // 6) % 2]
        else:
            idx = GHOST_FRAMES[i][(frame // 6) % 2]
        canvas.blit(art.sprites[idx], (round(cx) - 8, round(cy) - 7))
    screen.blit(pygame.transform.scale(canvas, (W * SCALE, H * SCALE)), (0, 0))
    # HUD in the black margins left/right of the maze
    lines = [("SCORE", WHITE), (str(game.score), YELLOW), ("", WHITE), ("LIVES", WHITE), (str(game.lives), YELLOW)]
    if game.game_over:
        lines += [("", WHITE), ("GAME OVER", RED), ("SPACE: retry", WHITE)]
    elif game.won:
        lines += [("", WHITE), ("YOU WIN", GREEN), ("SPACE: replay", WHITE)]
    for n, (text, colour) in enumerate(lines):
        if text:
            screen.blit(font.render(text, True, colour), (10, 20 + n * 26))


STEP_FRAMES = 7  # simulation step every 7 frames at 60 fps (~8.6 steps/s)


def snapshot(game):
    return {"pac": (game.pac.row, game.pac.col), "ghosts": [(g.row, g.col) for g in game.ghosts]}


async def main():
    pygame.init()
    screen = pygame.display.set_mode((W * SCALE, H * SCALE))
    pygame.display.set_caption("Pac-Man (Bataille 1984) - Python port")
    font = pygame.font.Font(None, 30)
    art = Art()
    clock = pygame.time.Clock()
    game = Game(seed=pygame.time.get_ticks() & 0xFFFF)
    prev = snapshot(game)
    requested = None
    frame = 0
    running = True
    while running:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    running = False
                elif e.key in KEYS:
                    requested = KEYS[e.key]
                elif e.key == pygame.K_SPACE and (game.game_over or game.won):
                    game = Game(seed=pygame.time.get_ticks() & 0xFFFF)
                    prev = snapshot(game)
        if frame % STEP_FRAMES == 0:
            prev = snapshot(game)
            game.step(requested)
        draw(screen, art, font, game, prev, (frame % STEP_FRAMES + 1) / STEP_FRAMES, frame)
        pygame.display.flip()
        frame += 1
        clock.tick(60)
        await asyncio.sleep(0)  # yield to the browser (required by pygbag)
    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
