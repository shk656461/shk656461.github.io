"""Pygame front end: python -m pacman_py (also runs in the browser via pygbag)."""

import asyncio

import pygame

from .game import COLS, DOT, DOWN, LEFT, PELLET, RIGHT, ROWS, TICK_SECONDS, UP, Game

import os

SCALE = 3
W, H = 320, 200            # CGA mode 4 resolution used by the original
ASSETS = os.path.join(os.path.dirname(__file__), "assets")
WHITE, YELLOW, GREEN, RED = (255, 255, 255), (255, 255, 85), (85, 255, 85), (255, 85, 85)
KEYS = {  # the original's keys: E/I up, D/J down, A/K left, S/L right (plus arrows)
    pygame.K_UP: UP, pygame.K_e: UP, pygame.K_i: UP,
    pygame.K_DOWN: DOWN, pygame.K_d: DOWN, pygame.K_j: DOWN,
    pygame.K_LEFT: LEFT, pygame.K_a: LEFT, pygame.K_k: LEFT,
    pygame.K_RIGHT: RIGHT, pygame.K_s: RIGHT, pygame.K_l: RIGHT,
}

# pacman.png: row = direction (up, down, left, right), column = animation frame
# (wide, medium, closed, medium). ghosts.png: row = colour set, column = dir*2 + feet.
# Both layouts were recovered from the original's sprite tables, see tools/extract_assets.py.
GHOST_FRIGHT, GHOST_FLASH = 4, 5


class Art:
    def __init__(self):
        load = lambda n: pygame.image.load(os.path.join(ASSETS, n))
        self.walls = load("walls.png")
        self.dot, self.pellet = load("dot.png"), load("pellet.png")
        def cut(name, cols, rows):
            sheet = load(name)
            out = []
            for r in range(rows):
                line = []
                for c in range(cols):
                    sp = sheet.subsurface((c * 16, r * 14, 16, 14)).copy()
                    sp.set_colorkey((0, 0, 0))
                    line.append(sp)
                out.append(line)
            return out

        self.pac = cut("pacman.png", 4, 4)
        self.ghosts = cut("ghosts.png", 8, 7)
        for t in (self.dot, self.pellet):
            t.set_colorkey((0, 0, 0))


def sprite_xy(offset):
    """Screen position of a sprite from its CGA buffer offset (bank bit 0x2000 = odd lines)."""
    o = offset & 0x1FFF
    return (o % 80) * 4, (o // 80) * 2 + ((offset >> 13) & 1)


def draw(screen, art, font, game, frame):
    canvas = pygame.Surface((W, H))
    canvas.blit(art.walls, (0, 0))
    for r in range(ROWS):
        for c in range(COLS):
            v = game.cell(r, c)
            pos = (52 + 8 * c, 8 * r - 4)
            if v == DOT:
                canvas.blit(art.dot, pos)
            elif v == PELLET and game.blink > 7:  # blink phase from ds:2CCB
                canvas.blit(art.pellet, pos)
    if game.pause == 0 or game.after is None:
        canvas.blit(art.pac[game.pac_dir][game.pac_frame], sprite_xy(game.pac_offset))
    for i, g in enumerate(game.ghosts):
        if g.mode >= 6:
            row = 6
        elif g.mode & 1:
            row = GHOST_FLASH if game.fright_timer <= 0x46 and game.blink >= 8 else GHOST_FRIGHT
        else:
            row = i
        canvas.blit(art.ghosts[row][g.direction * 2 + game.feet], sprite_xy(g.offset))
    screen.blit(pygame.transform.scale(canvas, (W * SCALE, H * SCALE)), (0, 0))
    lines = [("SCORE", WHITE), (str(game.score), YELLOW), ("", WHITE), ("LIVES", WHITE), (str(game.lives), YELLOW),
             ("", WHITE), ("LEVEL", WHITE), (str(game.level), YELLOW)]
    if game.game_over:
        lines += [("", WHITE), ("GAME OVER", RED), ("SPACE: retry", WHITE)]
    for n, (text, colour) in enumerate(lines):
        if text:
            screen.blit(font.render(text, True, colour), (10, 20 + n * 26))


async def main():
    pygame.init()
    screen = pygame.display.set_mode((W * SCALE, H * SCALE))
    pygame.display.set_caption("Pac-Man (Bataille 1984) - Python port")
    font = pygame.font.Font(None, 30)
    art = Art()
    clock = pygame.time.Clock()
    game = Game()
    frame = 0
    acc = 0.0  # the original runs one logic step per BIOS timer tick (18.2065 Hz)
    running = True
    while running:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    running = False
                elif e.key in KEYS:
                    game.press(KEYS[e.key])
                elif e.key == pygame.K_SPACE and game.game_over:
                    game = Game()
        acc += clock.get_time() / 1000.0
        acc = min(acc, 0.25)
        while acc >= TICK_SECONDS:
            acc -= TICK_SECONDS
            game.tick()
        draw(screen, art, font, game, frame)
        pygame.display.flip()
        frame += 1
        clock.tick(60)
        await asyncio.sleep(0)  # yield to the browser (required by pygbag)
    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
