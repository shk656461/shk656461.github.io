"""Pygame front end: python -m pacman_py (also runs in the browser via pygbag)."""

import asyncio

import pygame

from .game import COLS, DOT, DOWN, LEFT, PELLET, RIGHT, ROWS, UP, WALL, Game

TILE = 24
HUD = 32
# CGA palette 1 (cyan/magenta/white on black) like the DOS original
BLACK, CYAN, MAGENTA, WHITE = (0, 0, 0), (85, 255, 255), (255, 85, 255), (255, 255, 255)
YELLOW = (255, 255, 85)
KEYS = {
    pygame.K_UP: UP, pygame.K_w: UP, pygame.K_i: UP, pygame.K_e: UP,
    pygame.K_DOWN: DOWN, pygame.K_s: DOWN, pygame.K_j: DOWN, pygame.K_d: DOWN,
    pygame.K_LEFT: LEFT, pygame.K_a: LEFT, pygame.K_k: LEFT,
    pygame.K_RIGHT: RIGHT, pygame.K_l: RIGHT,
}


def draw(screen, font, game):
    screen.fill(BLACK)
    for r in range(ROWS):
        for c in range(COLS):
            v = game.grid[r][c]
            x, y = c * TILE, HUD + r * TILE
            if v == WALL:
                pygame.draw.rect(screen, CYAN, (x + 2, y + 2, TILE - 4, TILE - 4), 1)
            elif v == DOT:
                pygame.draw.circle(screen, WHITE, (x + TILE // 2, y + TILE // 2), 2)
            elif v == PELLET:
                pygame.draw.circle(screen, WHITE, (x + TILE // 2, y + TILE // 2), 6)
    p = game.pac
    pygame.draw.circle(screen, YELLOW, (p.col * TILE + TILE // 2, HUD + p.row * TILE + TILE // 2), TILE // 2 - 2)
    colour = CYAN if game.fright else MAGENTA
    for g in game.ghosts:
        pygame.draw.rect(screen, colour, (g.col * TILE + 3, HUD + g.row * TILE + 3, TILE - 6, TILE - 6))
    hud = f"SCORE {game.score:6d}   LIVES {game.lives}"
    if game.game_over:
        hud += "   GAME OVER - SPACE to retry"
    elif game.won:
        hud += "   YOU WIN - SPACE to replay"
    screen.blit(font.render(hud, True, WHITE), (8, 6))


async def main():
    pygame.init()
    screen = pygame.display.set_mode((COLS * TILE, HUD + ROWS * TILE))
    pygame.display.set_caption("Pac-Man (Bataille 1984) - Python port")
    font = pygame.font.Font(None, 24)
    clock = pygame.time.Clock()
    game = Game(seed=pygame.time.get_ticks() & 0xFFFF)
    requested = None
    running = True
    while running:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    running = False
                elif e.key in KEYS:
                    requested = KEYS[e.key]
                elif e.key == pygame.K_SPACE and (game.game_over or game.won):
                    game = Game(seed=pygame.time.get_ticks() & 0xFFFF)
        game.step(requested)
        draw(screen, font, game)
        pygame.display.flip()
        clock.tick(8)
        await asyncio.sleep(0)  # yield to the browser (required by pygbag)
    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
