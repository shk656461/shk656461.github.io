"""Pygame front end: python -m pacman_py (also runs in the browser via pygbag)."""

import asyncio

import pygame

from .orig import Sim
from .sound import Audio
from .game import COLS, DOT, DOWN, LEFT, PELLET, RIGHT, ROWS, TICK_SECONDS, UP, Game, DEATH_FRAMES, DEATH_FREEZE, CLEAR_FREEZE, CLEAR_FLASH_TICKS

import os

SCALE = 3
W, H = 320, 200            # CGA mode 4 resolution used by the original
ASSETS = os.path.join(os.path.dirname(__file__), "assets")
WHITE, YELLOW, GREEN, RED = (255, 255, 255), (255, 255, 85), (85, 255, 85), (255, 85, 85)
KEYS = {  # the original's keys: E/I up, D/J down, A/K left, S/L right (plus arrows)
    pygame.K_UP: UP, pygame.K_e: UP, pygame.K_i: UP,
    pygame.K_DOWN: DOWN, pygame.K_d: DOWN, pygame.K_j: DOWN,
    pygame.K_LEFT: LEFT, pygame.K_a: LEFT, pygame.K_k: LEFT,
    pygame.K_RIGHT: RIGHT, pygame.K_s: RIGHT, pygame.K_l: RIGHT,
}

# pacman.png: row = direction (up, down, left, right), column = animation frame
# (wide, medium, closed, medium). ghosts.png: row = colour set, column = dir*2 + feet.
# Both layouts were recovered from the original's sprite tables, see tools/extract_assets.py.
GHOST_FRIGHT, GHOST_FLASH = 4, 5


class Art:
    def fruit_cur(self, rec):
        if rec not in self._fcache:
            self._fcache[rec] = cga_surface(fruit_rows(self.sim, rec))
        return self._fcache[rec]

    def fruit_sprite(self, i):
        return self.fruit_cur(0x2D2E + i * 0x3B)

    def death(self, f):
        return self.fruit_cur(0x2675 + 56 * f - 3)  # same 4x14-byte layout, 3 bytes after the record start

    def popup(self, sim):
        return cga_surface(popup_rows(sim))

    def __init__(self):
        load = lambda n: pygame.image.load(os.path.join(ASSETS, n))
        self.walls = load("walls.png")
        self.dot, self.pellet = load("dot.png"), load("pellet.png")
        def cut(name, cols, rows):
            sheet = load(name)
            out = []
            for r in range(rows):
                line = []
                for c in range(cols):
                    sp = sheet.subsurface((c * 16, r * 14, 16, 14)).copy()
                    sp.set_colorkey((0, 0, 0))
                    line.append(sp)
                out.append(line)
            return out

        self._fcache = {}
        self.sim = Sim()  # static tables (fruit sprites)
        self.disc = self.fruit_cur(0x1DD1 - 3)  # 0x3A2: full Pac-Man disc shown when the level is cleared
        self.life = self.fruit_cur(0x1F59 - 3)  # 0x1F59: the Pac-Man life icon
        self.pac = cut("pacman.png", 4, 4)
        self.ghosts = cut("ghosts.png", 8, 7)
        for t in (self.dot, self.pellet):
            t.set_colorkey((0, 0, 0))


def sprite_xy(offset):
    """Screen position of a sprite from its CGA buffer offset (bank bit 0x2000 = odd lines)."""
    o = offset & 0x1FFF
    return (o % 80) * 4, (o // 80) * 2 + ((offset >> 13) & 1)


def blit_clipped(canvas, sprite, offset, rows):
    """The original draws only `rows` lines of a sprite (field +8): it hides sprites leaving through the tunnel."""
    if rows > 0:
        canvas.blit(sprite, sprite_xy(offset), (0, 0, sprite.get_width(), rows))


# 8x8 glyphs of the BIOS font for "PRET !" (the original prints them with int 10h and copies them down the screen)
FONT = {
    "P": (0xFC, 0x66, 0x66, 0x7C, 0x60, 0x60, 0xF0, 0x00),
    "R": (0xFC, 0x66, 0x66, 0x7C, 0x6C, 0x66, 0xE6, 0x00),
    "E": (0xFE, 0x62, 0x68, 0x78, 0x68, 0x62, 0xFE, 0x00),
    "T": (0xFC, 0xB4, 0x30, 0x30, 0x30, 0x30, 0x78, 0x00),
    "!": (0x30, 0x78, 0x78, 0x30, 0x30, 0x00, 0x30, 0x00),
    " ": (0,) * 8,
}
ALT_PALETTE = {(85, 255, 85): (0, 170, 170), (255, 85, 85): (170, 0, 170), (255, 255, 85): (170, 170, 170)}


def draw_ready(canvas):
    """0x31A-0x34B: six red 8x8 characters stacked downward from screen offset 0x0C07."""
    x, y = sprite_xy(0x0C07)
    for n, ch in enumerate("PRET !"):
        for r, bits in enumerate(FONT[ch]):
            for b in range(8):
                if bits & (0x80 >> b):
                    canvas.set_at((x + b, y + n * 8 + r), (255, 85, 85))


CGA = [(0, 0, 0), (85, 255, 85), (255, 85, 85), (255, 255, 85)]


def cga_surface(rows):
    """rows: list of byte strings, 4 pixels per byte, 2 bits each (CGA mode 4)."""
    surf = pygame.Surface((len(rows[0]) * 4, len(rows)))
    for y, row in enumerate(rows):
        for x, byte in enumerate(row):
            for k in range(4):
                surf.set_at((x * 4 + k, y), CGA[(byte >> (6 - 2 * k)) & 3])
    return surf


def fruit_rows(sim, rec):
    data = bytes(sim.m[rec + 3 : rec + 3 + 56])
    return [data[i * 4 : i * 4 + 4] for i in range(14)]


def popup_rows(sim):
    buf = bytes(sim.m[0x2F45 : 0x2F45 + 40])
    return [b"\0" + buf[i * 2 : i * 2 + 2] + b"\0" for i in range(20)]


def draw_kill_popup(canvas, popup):
    """Points shown at a ghost kill (0xD19): 4-byte rows written at the original's CGA offsets."""
    di, rows, data = popup
    dx, bp = 0xE04C, 0x1FFC
    for r in range(rows):
        d = di & 0x3FFF
        y = ((d & 0x1FFF) // 80) * 2 + (d >> 13)
        x = (d & 0x1FFF) % 80 * 4
        for i, byte in enumerate(data[r * 4 : r * 4 + 4]):
            for k in range(4):
                c = (byte >> (6 - 2 * k)) & 3
                px = x + i * 4 + k
                if c and 0 <= px < W and 0 <= y < H:
                    canvas.set_at((px, y), CGA[c])
        di = (di + 4 + dx) & 0xFFFF
        dx, bp = bp, dx


def draw(screen, art, font, game, frame):
    canvas = pygame.Surface((W, H))
    canvas.blit(art.walls, (0, 0))
    for r in range(ROWS):
        for c in range(COLS):
            v = game.cell(r, c)
            pos = (52 + 8 * c, 8 * r - 4)
            if v == DOT:
                canvas.blit(art.dot, pos)
            elif v == PELLET and game.blink > 7:  # blink phase from ds:2CCB
                canvas.blit(art.pellet, pos)
    sim = game.sim
    # level indicator: the original blits fruit records 0..min(level,8)-1 at x=36, 8 lines apart
    for i in range(min(game.level, 8)):  # 0x239: each icon 14 lines tall, 16 lines apart
        canvas.blit(art.fruit_sprite(i), (36, 186 - 16 * i))
    for k in range(1, game.lives):  # 0x267: lives-1 Pac-Man icons at 0x1F3B - 640*k
        canvas.blit(art.life, (300, 198 - 16 * k))
    # bonus fruit and its score pop-up, at the original's fixed screen position
    if game.fruit_state == 2:
        canvas.blit(art.fruit_cur(sim.w(0x2F41)), (152, 93))
    dt = game.death_tick
    ct = game.clear_tick
    if ct is not None:  # 0x39A: the last dot is eaten, Pac-Man turns into a full disc, then the ghosts are wiped
        blit_clipped(canvas, art.disc, game.pac_offset, sim.f(0, 8))
    elif dt is None:
        blit_clipped(canvas, art.pac[game.pac_dir][game.pac_frame], game.pac_offset, sim.f(0, 8))
    elif 0 <= dt - DEATH_FREEZE < 2 * DEATH_FRAMES:  # 0x421: one frame per two ticks
        blit_clipped(canvas, art.death((dt - DEATH_FREEZE) // 2), game.pac_offset, sim.f(0, 8))
    elif dt < DEATH_FREEZE:
        blit_clipped(canvas, art.pac[game.pac_dir][game.pac_frame], game.pac_offset, sim.f(0, 8))
    for i, g in enumerate(game.ghosts):
        if (dt is not None and dt >= DEATH_FREEZE) or (ct is not None and ct >= CLEAR_FREEZE):
            break  # 0x3C1: the ghosts are wiped
        if g.mode >= 6:
            row = 6
        elif g.mode & 1:
            row = GHOST_FLASH if game.fright_timer <= 0x46 and game.blink >= 8 else GHOST_FRIGHT
        else:
            row = i
        blit_clipped(canvas, art.ghosts[row][g.direction * 2 + game.feet], g.offset, sim.f(i + 1, 8))
    if game.kill_popup:
        draw_kill_popup(canvas, game.kill_popup)
    if game.fruit_state == 1:
        canvas.blit(art.popup(sim), (152, 88))
    if game.ready:
        draw_ready(canvas)
    if ct is not None and ct >= CLEAR_FREEZE and ((ct - CLEAR_FREEZE) // CLEAR_FLASH_TICKS) % 2 == 1:
        px = pygame.PixelArray(canvas)  # 0x3F3: the palette toggles between the two CGA palettes
        for old, new in ALT_PALETTE.items():
            px.replace(old, new)
        px.close()
    screen.blit(pygame.transform.scale(canvas, (W * SCALE, H * SCALE)), (0, 0))
    lines = [("SCORE", WHITE), (str(game.score), YELLOW), ("", WHITE), ("LIVES", WHITE), (str(game.lives), YELLOW),
             ("", WHITE), ("LEVEL", WHITE), (str(game.level), YELLOW)]
    if game.game_over:
        lines += [("", WHITE), ("GAME OVER", RED), ("SPACE: retry", WHITE)]
    for n, (text, colour) in enumerate(lines):
        if text:
            screen.blit(font.render(text, True, colour), (10, 20 + n * 26))


async def main():
    pygame.init()
    screen = pygame.display.set_mode((W * SCALE, H * SCALE))
    pygame.display.set_caption("Pac-Man (Bataille 1984) - Python port")
    font = pygame.font.Font(None, 30)
    art = Art()
    clock = pygame.time.Clock()
    game = Game()
    audio = Audio(pygame)
    frame = 0
    acc = 0.0  # the original runs one logic step per BIOS timer tick (18.2065 Hz)
    running = True
    while running:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    running = False
                elif e.key in KEYS:
                    game.press(KEYS[e.key])
                elif e.key == pygame.K_SPACE and game.game_over:
                    game = Game()
        acc += clock.get_time() / 1000.0
        acc = min(acc, 0.25)
        while acc >= TICK_SECONDS:
            acc -= TICK_SECONDS
            game.tick()
            audio.tone(game.tone)
            if any(isinstance(e, tuple) and e[0] == "ghost" for e in game.events):
                audio.jingle([game.sim.w(0x2FF6 + 2 * i) for i in range(24)])
        draw(screen, art, font, game, frame)
        pygame.display.flip()
        frame += 1
        clock.tick(60)
        await asyncio.sleep(0)  # yield to the browser (required by pygbag)
    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
