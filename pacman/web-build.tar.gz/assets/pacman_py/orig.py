"""Literal port of the movement / ghost logic of F. Bataille's 1984 Pacman.

Every routine mirrors the 8086 code in the original (addresses in comments are
offsets in the code segment).  Data lives in a 64 KB byte array laid out like the
original data segment, so even out-of-bounds reads behave the same.

Entity record (stride 0x7C, entity 0 = Pac-Man, 1..4 = ghosts):
    +0 direction (0 up, 1 down, 2 left, 3 right)   ds:2A2D
    +1 screen offset word                            ds:2A2E
    +3 v  vertical position in half cells            ds:2A30
    +4 h  horizontal position in half cells          ds:2A31
    +10 skip flag (2 = lose next tick, 1 = turned)   ds:2A37
    +11 mode: 0 chase, 1 fright, 2/3 leaving house, 4/5 in house, 6/7 eyes (bit0 = fright)
One call of tick() is one iteration of the main loop (one BIOS timer tick, 18.2 Hz).
"""

from .orig_tables import CHUNKS

STRIDE = 0x7C
ENT = 0x2A2D
MAZE = 0x1673


def s8(x):
    x &= 0xFF
    return x - 256 if x & 0x80 else x


class Sim:
    def __init__(self):
        self.m = bytearray(0x10000)
        for a, b in CHUNKS.items():
            self.m[a : a + len(b)] = b
        self.score = [0] * 5  # digits, ds:2F7E.. (the original shows them followed by a 0)
        self.lives = 3
        self.level = 0
        self.dead = False
        self.cleared = False
        self.events = []
        self.tone = None
        self.new_game()

    # -- memory helpers
    def b(self, a):
        return self.m[a & 0xFFFF]

    def sb(self, a, v):
        self.m[a & 0xFFFF] = v & 0xFF

    def w(self, a):
        return self.m[a] | self.m[a + 1] << 8

    def sw(self, a, v):
        self.m[a] = v & 0xFF
        self.m[a + 1] = (v >> 8) & 0xFF

    def f(self, k, off):  # entity field
        return self.m[ENT + STRIDE * k + off]

    def sf(self, k, off, v):
        self.m[ENT + STRIDE * k + off] = v & 0xFF

    # field shortcuts
    def dir(self, k): return self.f(k, 0)
    def off(self, k): return self.w(ENT + STRIDE * k + 1)
    def v(self, k): return self.f(k, 3)
    def h(self, k): return self.f(k, 4)
    def m37(self, k): return self.f(k, 10)
    def mode(self, k): return self.f(k, 11)

    # -- random generator, 0xB08
    def rand(self):
        x = self.w(0x2D24)
        x = (x * 0x98DD + 0xD5EF) & 0xFFFF
        self.sw(0x2D24, x)
        return x

    # -- score, 0xE48: add `val` at decimal digit `pos` (4 = units) with carry
    def add_score(self, val, pos):
        """0xE48.  The loop runs at most `pos` times (digits pos..1; digit 0 is never touched);
        afterwards 0xE6B awards an extra life when digit 1 was the last one written, digit 0 is 0 and digit 1 is 1."""
        di, al, cx, last = pos, val, pos, None
        while True:
            al += self.score[di]
            ah, al = divmod(al, 10)
            self.score[di] = al
            last = di
            di -= 1
            al = ah
            cx -= 1
            if cx == 0 or al == 0:
                break
        if last == 1 and self.score[0] == 0 and self.score[1] == 1:
            self.extra_life()  # 0xB1F

    def extra_life(self):
        self.sb(0x2F93, 0x18)
        self.lives += 1
        self.events.append("extra")

    def score_value(self):
        n = 0
        for dgt in self.score:
            n = n * 10 + dgt
        return n * 10

    # -- game / level / life set-up
    def new_game(self):
        self.sw(0x2D24, 0)  # 0xF5: the generator is reseeded with 0
        self.lives = 3
        self.level = 0
        self.score = [0] * 5
        self.start_level()

    def start_level(self):  # 0x186-0x25E
        self.m[MAZE : MAZE + 0x377] = self.m[0x19EA : 0x19EA + 0x377]
        self.sb(0x2C99, 0xE6)
        self.level = min(self.level + 1, 12)
        si = 0x6EF + self.level * 4
        self.sb(0x2C9A, self.b(si))
        self.sb(0x2D26, self.b(si + 1))
        self.sw(0x2D27, self.w(si + 2))
        self.start_life()

    def start_life(self):  # 0x2A6-0x2D0
        self.m[ENT : ENT + 0x26C] = self.m[0x725 : 0x725 + 0x26C]
        self.m[0x2F90 : 0x2F98] = bytes(8)  # 0x2AA: sound flags
        self.sw(0x2C9B, 0)
        self.sb(0x2CC9, 0)
        self.sb(0x2CBC, 0)
        self.dead = False
        self.cleared = False

    # -- keyboard, 0xD74 (keyboard mode); key is a direction 0..3 or None
    def request(self, d):
        self.sb(0x2CBC, d)

    # -- ghost direction chooser, 0x961
    def choose(self, bx, bp):
        m = self.m
        for i in range(4):
            m[0x2D2A + i] = 1
        mode = self.mode(bx)
        a = mode >> 1
        if a == 0:
            return self._a32(bx, bp)
        if a == 1:  # 0x97B: leaving the house
            return self._97b(bx)
        if a == 2:  # 0x9B0: in the house
            return self._9b0(bx)
        return self._9f9(bx, bp)  # eyes

    def _97b(self, bx):
        diff = (self.off(bx) - 0x2E92) & 0xFFFF
        if diff == 0:
            self.sf(bx, 11, self.mode(bx) - 2)
            self.sf(bx, 3, 0x19)
            self.sf(bx, 4, 0x26)
            return (self.rand() >> 15) & 1
        if diff > 0xFFE2:
            return 3
        return (diff >> 15) & 1

    def _9b0(self, bx):
        al = self.dir(bx)
        idx = bx
        si = (al + 2 * idx) * 2
        if self.off(bx) == self.w(0x2D0C + si):
            al ^= 1
            if al == 3 and not (self.mode(bx) & 1):
                r = self.rand()
                if r < self.w(0x2D27):
                    self.sf(bx, 11, self.mode(bx) - 2)
                    return self._97b(bx)
                return 3
            return al
        return al

    def _9f9(self, bx, bp):
        if self.v(bx) == 0x1A and self.h(bx) == 0x26:
            self.sf(bx, 11, self.mode(bx) - 2)
            si = bx * 4
            self.sw(ENT + STRIDE * bx + 1, self.w(0x2D10 + si))
            if bx * 4 == 0xC:
                self.sf(bx, 11, self.mode(bx) - 2)
            self.sf(bx, 0, 3)
            return 3
        return self._a32(bx, bp)

    def _a32(self, bx, bp):
        m = self.m
        m[0x2D29] = m[0x2D26]
        dl = self.mode(bx)
        cx = (dl ^ 1) & 1
        if dl >= 6:
            m[0x2D29] = 0x3C
            cx = 1
        al = self.v(0) if dl < 6 else 0x1A
        al = (al - self.v(bx)) & 0xFF
        if cx:
            al = (-al) & 0xFF
        if al:
            m[0x2D2A + (1 if al & 0x80 else 0)] = m[0x2D29]
        al = self.h(0) if dl < 6 else 0x26
        al = (al - self.h(bx)) & 0xFF
        if cx:
            al = (-al) & 0xFF
        if al:
            m[0x2D2A + 2 + (1 if al & 0x80 else 0)] = m[0x2D29]
        for cx in range(4, 0, -1):  # wall check, 0xA9B
            nb = s8(m[0x2CBC + cx])
            if m[(MAZE + bp + nb) & 0xFFFF] == 0:
                m[0x2D29 + cx] = 0
        di = self.dir(bx)
        if self.m37(bx) != 1:
            if (((self.h(bx) ^ 0x20) << 8 | di) & 0xFFFE) != 0:
                m[0x2D2A + di] = (m[0x2D2A + di] << 1) & 0xFF
        m[0x2D2A + (di ^ 1)] = 0
        bp2 = sum(m[0x2D2A : 0x2D2E])
        dx = (self.rand() * bp2) >> 16
        i = 0x2D2A
        while True:
            dx -= m[i]
            i += 1
            if dx < 0:
                break
        return i - 0x2D2B

    # -- move one entity step in its current direction, 0x720-0x747
    def _advance(self, bx, al):
        si = al * 2
        off = self.w(ENT + STRIDE * bx + 1)
        d = self.w(0x2CC1 + si)
        self.sw(ENT + STRIDE * bx + 1, off + d)
        delta = 1 if al & 1 else -1
        idx = al >> 1
        self.sf(bx, 3 + idx, self.f(bx, 3 + idx) + delta)
        return idx, delta

    # -- the main loop body, 0x4F0-0x8DC.  Returns 'ok', 'dead' or 'clear'.
    def tick(self, req=None):
        m = self.m
        self.events = []
        if req is not None:
            self.sb(0x2CBC, req)
        self.sw(0x2CCE, 0)
        self.sb(0x2CCA, self.b(0x2CCA) + 1)
        t = self.b(0x2C9B)
        if t:
            t -= 1
            self.sb(0x2C9B, t)
            if t == 0:
                for k in range(4, 0, -1):
                    self.sf(k, 11, self.mode(k) & 0xFE)
        self.sb(0x2CCB, self.b(0x2CCB) - 1)
        if self.b(0x2CCB) == 0:
            self.sb(0x2CCB, 0x0E)
        pac_moves = self._pac()
        if pac_moves == "clear":
            self.cleared = True
            return "clear"
        self._ghosts()
        self._wrap()
        self.tone = self._sound()
        self._fruit()
        return self._collide()

    # Pac-Man, 0x57D-0x6B5
    def _pac(self):
        m = self.m
        v, h = self.v(0), self.h(0)
        if (h & 1) or (v & 1):
            # 0x64D: between cells only a reversal on the same axis is accepted
            al = self.dir(0) ^ self.b(0x2CBC)
            if not (al & 2):
                self.sf(0, 0, self.b(0x2CBC))
            return self._move_pac()
        bx = (v >> 1) * 30 + (h >> 1)
        stage = "a7" if self.b(MAZE + bx) <= 1 else "eat"
        while True:
            if stage == "eat":  # 0x5E2
                self.add_score(1, 4)
                old = self.b(MAZE + bx)
                self.sb(MAZE + bx, 1)
                self.events.append("dot")
                if old == 3:
                    self.sb(0x2F91, 0x19)
                    self.events.append("pellet")
                    self.add_score(4, 4)
                    self.sw(0x2F8D, 0)
                    self.sb(0x2C9B, self.b(0x2C9A))
                    for k in range(4, 0, -1):
                        self.sf(k, 11, self.mode(k) | 1)
                        self.sf(k, 0, self.dir(k) ^ 1)
                self.sb(0x2C99, self.b(0x2C99) - 1)
                if self.b(0x2C99) == 0:
                    return "clear"
                self.sb(0x2F90, 2)
                self.sb(0x2CCC, -s8(self.b(0x2CCC)))
                if s8(self.b(0x2CCC)) > 0:
                    stage = "a7"
                    continue
                self.sb(0x2F90, 3)
                self.sw(0x2CCE, 0x7C)  # Pac-Man loses this tick
                return False
            # 0x5A7
            req = self.b(0x2CBC)
            nb = s8(self.b(0x2CBD + req))
            if self.b(MAZE + bx + nb) != 0:
                self.sf(0, 0, req)
                return self._move_pac()
            cur = self.dir(0)
            nb = s8(self.b(0x2CBD + cur))
            if self.b(MAZE + bx + nb) != 0:
                return self._move_pac()
            return False

    def _move_pac(self):  # 0x65E
        d = self.dir(0)
        self._advance(0, d)
        self.sb(0x2CC9, (self.b(0x2CC9) + 1) & 3)
        return True

    # ghosts, 0x6B6-0x76F
    def _ghosts(self):
        for bx in range(4, 0, -1):
            self._ghost(bx)

    def _ghost(self, bx):
        if s8(self.m37(bx)) >= 2:
            self.sf(bx, 10, 1)
            return
        v, h = self.v(bx), self.h(bx)
        if (h & 1) or (v & 1):
            al = self.dir(bx)
            ccd = 1
        else:
            ccd = 0
            bp = (v >> 1) * 30 + (h >> 1)
            al = self.choose(bx, bp)
            if self.dir(bx) != al:
                old = self.dir(bx)
                self.sf(bx, 0, al)
                if self.m37(bx) != 1:
                    self.sf(bx, 0, old)
                    self.sf(bx, 10, 1)
                    return
        while True:  # 0x720
            idx, delta = self._advance(bx, al)
            self.sf(bx, 10, 0)
            if 2 <= s8(self.mode(bx)) < 6:
                self.sf(bx, 3 + idx, self.f(bx, 3 + idx) - delta)
            if ccd == 1:
                return
            if s8(self.mode(bx)) >= 6:  # eyes take a second step
                al = self.dir(bx)
                ccd = 1
                continue
            return

    # 0x77D: vertical wrap and speed flags
    def _wrap(self):
        for bx in range(5):
            al = s8(self.v(bx))
            if al < 0 or al > 0x39:
                adj = 0x3A if al < 0 else -0x3A
                dx = 0x2440 if al < 0 else -0x2440
                self.sf(bx, 3, al + adj)
                self.sw(ENT + STRIDE * bx + 1, self.off(bx) + dx)
                al = s8(self.v(bx))
            if self.m37(bx) != 1:
                if self.h(bx) == 0x20:
                    self.sf(bx, 10, 2)
                    if 0x0C <= al <= 0x26:
                        self.sf(bx, 10, 0)
                if self.mode(bx) != 0 and s8(self.mode(bx)) < 6:
                    self.sf(bx, 10, 2)
            # 0x7D0: visible height of the sprite (rows), 0xCF - 4*v clamped to 0..14
            self.sf(bx, 8, max(0, min(14, 0xCF - 4 * self.v(bx))))

    # 0x89E: Pac-Man against the ghosts
    def _collide(self):
        res = "ok"
        for bx in range(4, 0, -1):
            if s8(self.mode(bx)) >= 2:
                continue
            d = abs(self.v(bx) - self.v(0)) + abs(self.h(bx) - self.h(0))
            if d > 2:
                continue
            if self.mode(bx) == 0:
                self.dead = True
                return "dead"
            self._eat_ghost(bx)
        return res

    def _eat_ghost(self, bx):  # 0xCBD
        di = self.w(0x2F8D)
        self.add_score(self.b(0x25F1 + di), 3)
        self.sf(bx, 11, 6)
        self.sw(0x2F8D, di + 0x21)
        self.events.append(("ghost", bx, di // 0x21))

    # -- bonus fruit, 0xB63-0xC57 (states in ds:2F43: 0 idle, 1 score shown, 2 fruit on screen)
    FRUIT_POS = 0x2E86

    def _sound(self):
        """0xF2F: every non-zero flag in ds:2F90..2F97 is decremented; the highest one picks the tone.
        Returns the PIT divisor to play for this tick, or None for silence."""
        si = 0
        ah = 0
        for i in range(8):
            v = self.b(0x2F90 + i)
            if v:
                ah = (v - 1) & 0xFF
                self.sb(0x2F90 + i, ah)
                si = i + 1
        if si == 0 or s8(self.b(0x2FA0)) < 0:
            return None
        if si == 1:  # 0xFA9: dot, two alternating tones
            n = self.b(0x2FA1) + 1
            n = 0 if n >= 8 else n
            self.sb(0x2FA1, n)
            d = self.w(0x2FB4 + 2 * n)
        elif si == 2:  # 0xF98: power pellet
            d = self.w(0x2FC4 + 2 * ah)
        elif si == 3:  # 0xF87: fruit
            d = self.w(0x2FA2 + 2 * ah)
        elif si == 4:  # 0xF78: extra life
            d = 0x190 if ah & 1 else 2
        else:
            return None
        return None if d <= 2 else d

    def _fruit(self):
        self.sb(0x2F44, 0)
        st = self.b(0x2F43)
        if st == 2 and self.off(0) == self.FRUIT_POS:  # 0xB6F: Pac-Man reaches the fruit
            self.sb(0x2F92, 9)
            self.events.append("fruit")
            self.sb(0x2F43, 1)
            self.sw(0x2F3E, 0x3C)
            bx = self.w(0x2F41)
            dig = list(self.m[bx : bx + 3])
            buf = bytearray(40)
            di = 0
            pos = 0
            n = 3
            if dig[0] == 0:  # blank leading digit, 0xB99
                di = 4
                pos = 1
                n = 2
                buf[0:4] = bytes(4)
                buf[0x22:0x28] = bytes(6)
            for k in range(pos, 3):
                g = 0x2F06 + dig[k] * 8
                buf[di : di + 8] = self.m[g : g + 8]
                di += 10
            buf[di : di + 8] = self.m[0x2F06 : 0x2F0E]
            self.m[0x2F45 : 0x2F45 + 40] = buf
            for k in range(3):
                self.add_score(dig[k], 2 + k)
            self.sb(0x2F44, 2)
            return
        if st == 0:  # 0xBF1
            dots = self.b(0x2C99)
            if dots == self.b(0x2F40) or dots not in (0xAA, 0x50):
                return
            self.sb(0x2F40, dots)
            self.sb(0x2F43, 2)
            self.sw(0x2F3E, 0x87)
            self.sb(0x2F44, 3)
            idx = self.level - 1
            if idx >= 8:
                idx = (self.rand() >> 13) & 7
            rec = 0x2D2E + idx * 0x3B
            self.sw(0x2F41, rec)
            self.m[0x2F45 : 0x2F45 + 56] = self.m[rec + 3 : rec + 3 + 56]
            return
        # 0xC50
        t = (self.w(0x2F3E) - 1) & 0xFFFF
        self.sw(0x2F3E, t)
        if t == 0:
            self.sb(0x2F43, 0)
            self.sw(0x2F3E, 0x10E)
            self.sb(0x2F44, 1)
