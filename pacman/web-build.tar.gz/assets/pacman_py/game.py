"""Headless Pac-Man game logic, modelled on F. Bataille's 1984 DOS version.

Rules recovered from the disassembly (static analysis; not pixel exact):
- The level grid is 30x25 cells (0 wall / 1 empty / 2 dot / 3 power pellet).
  The original keeps actor positions in half-cell units and looks up
  cell (R>>1, C>>1); this port moves one whole cell per step instead.
- At a centre the ghost weights the 4 directions by the offset to Pac-Man,
  zeroes walls and the reverse, then picks randomly with an LCG
  (x = x*0x98DD + 0xD5EF, 16 bit).
"""

from dataclasses import dataclass, field

from .maze_data import MAZE

COLS, ROWS = 30, 25
UP, DOWN, LEFT, RIGHT = 0, 1, 2, 3
DELTA = {UP: (-1, 0), DOWN: (1, 0), LEFT: (0, -1), RIGHT: (0, 1)}
OPPOSITE = {UP: DOWN, DOWN: UP, LEFT: RIGHT, RIGHT: LEFT}
WALL, EMPTY, DOT, PELLET = 0, 1, 2, 3

PACMAN_START = (12, 7)  # unit (25,14) in the original records
GHOST_STARTS = [(13, 19), (13, 19), (12, 19), (13, 19)]  # original records: units (26,38)/(25,38)
FRIGHT_STEPS = 40
START_LIVES = 3


class LCG:
    """16 bit generator used by the original (seed lives at ds:0x2D24)."""

    def __init__(self, seed=0):
        self.x = seed & 0xFFFF

    def next(self):
        self.x = (self.x * 0x98DD + 0xD5EF) & 0xFFFF
        return self.x


@dataclass
class Actor:
    row: int
    col: int
    direction: int = LEFT
    start: tuple = (0, 0)


@dataclass
class Game:
    seed: int = 0
    grid: list = field(default_factory=lambda: [list(r) for r in MAZE])
    score: int = 0
    lives: int = START_LIVES
    level: int = 1
    fright: int = 0
    game_over: bool = False
    won: bool = False

    def __post_init__(self):
        self.rng = LCG(self.seed)
        self.pac = Actor(*PACMAN_START, direction=LEFT, start=PACMAN_START)
        self.want = LEFT
        self.ghosts = [Actor(r, c, UP, (r, c)) for r, c in GHOST_STARTS]
        self.dots_left = sum(row.count(DOT) + row.count(PELLET) for row in self.grid)

    # -- helpers
    def open(self, row, col):
        # horizontal tunnel wraps
        col %= COLS
        return 0 <= row < ROWS and self.grid[row][col] != WALL

    def step_pos(self, row, col, direction):
        dr, dc = DELTA[direction]
        return row + dr, (col + dc) % COLS

    # -- ghost AI (see disasm 0x0A32-0x0B07)
    def ghost_direction(self, g):
        weights = [0, 0, 0, 0]
        target = self.pac if self.fright == 0 else None
        for d in range(4):
            if d == OPPOSITE[g.direction]:
                continue
            nr, nc = self.step_pos(g.row, g.col, d)
            if not self.open(nr, nc):
                continue
            w = 1
            if target is not None:
                dr, dc = DELTA[d]
                # direction counts more when it closes the gap to Pac-Man
                if (target.row - g.row) * dr > 0 or (target.col - g.col) * dc > 0:
                    w = 4
            weights[d] = w
        total = sum(weights)
        if total == 0:
            return OPPOSITE[g.direction]
        pick = self.rng.next() % total
        for d, w in enumerate(weights):
            if pick < w:
                return d
            pick -= w
        return g.direction

    def can_turn(self, direction):
        """True if Pac-Man would change heading to `direction` on the next step."""
        if self.game_over or self.won or direction == self.pac.direction:
            return False
        nr, nc = self.step_pos(self.pac.row, self.pac.col, direction)
        return self.open(nr, nc)

    # -- one simulation step
    def step(self, requested=None):
        if self.game_over or self.won:
            return
        if requested is not None:
            self.want = requested
        p = self.pac
        nr, nc = self.step_pos(p.row, p.col, self.want)
        if self.open(nr, nc):
            p.direction = self.want
        else:
            nr, nc = self.step_pos(p.row, p.col, p.direction)
            if not self.open(nr, nc):
                nr, nc = p.row, p.col
        p.row, p.col = nr, nc
        cell = self.grid[p.row][p.col]
        if cell == DOT:
            self.score += 10
            self.dots_left -= 1
            self.grid[p.row][p.col] = EMPTY
        elif cell == PELLET:
            self.score += 50
            self.dots_left -= 1
            self.fright = FRIGHT_STEPS
            self.grid[p.row][p.col] = EMPTY
        if self.fright:
            self.fright -= 1
        self._collide()
        for g in self.ghosts:
            g.direction = self.ghost_direction(g)
            g.row, g.col = self.step_pos(g.row, g.col, g.direction)
        self._collide()
        if self.dots_left == 0:
            self.won = True

    def _collide(self):
        for g in self.ghosts:
            if (g.row, g.col) == (self.pac.row, self.pac.col):
                if self.fright:
                    self.score += 200
                    g.row, g.col = g.start
                else:
                    self.lives -= 1
                    if self.lives <= 0:
                        self.game_over = True
                    else:
                        self.pac.row, self.pac.col = self.pac.start
                        for x in self.ghosts:
                            x.row, x.col = x.start
                    return
