"""Game wrapper around the literal port of the original's logic (see orig.py)."""

from collections import deque

from .orig import ENT, MAZE, STRIDE, Sim

UP, DOWN, LEFT, RIGHT = 0, 1, 2, 3
COLS, ROWS = 30, 25
WALL, EMPTY, DOT, PELLET = 0, 1, 2, 3
TICK_SECONDS = 65536 / 1193182 * 1.0 * 1  # BIOS timer: 18.2065 Hz
EAT_PAUSE = 3      # the original's 0.44 s wait is its 24-note kill jingle; no sound here, so much shorter
READY_TICKS = 16   # 0x361: "PRET !" is shown for a busy-wait of ~1.2 s on the original's 4.77 MHz clock
CLEAR_FLASHES = 7  # 0x3F3: the palette toggles 7 times, ~0.35 s each
CLEAR_FLASH_TICKS = 6
CLEAR_FREEZE = 2   # 0x3B3 wait before the flashing starts
DEATH_FREEZE = 9   # 0x3B3: ~0.47 s busy-wait, then the ghosts are wiped
DEATH_FRAMES = 17  # 0x2675.. : 17 sprites of 56 bytes, each shown for 2 BIOS ticks (0x421)
DEATH_PAUSE = DEATH_FREEZE + 2 * DEATH_FRAMES + 2
CLEAR_PAUSE = CLEAR_FREEZE + CLEAR_FLASHES * CLEAR_FLASH_TICKS


class Ghost:
    def __init__(self, sim, k):
        self.sim, self.k = sim, k

    @property
    def direction(self): return self.sim.dir(self.k)
    @property
    def v(self): return self.sim.v(self.k)
    @property
    def h(self): return self.sim.h(self.k)
    @property
    def mode(self): return self.sim.mode(self.k)
    @property
    def offset(self): return self.sim.off(self.k)


class Game:
    def __init__(self):
        self.sim = Sim()
        self.keys = deque(maxlen=4)
        self.pause = 0
        self.after = None
        self.game_over = False
        self.ghosts = [Ghost(self.sim, k) for k in range(1, 5)]
        self.events = []
        self.ready = READY_TICKS  # ticks left of the "PRET !" wait before play starts
        self.clear_tick = None  # ticks since the last dot was eaten
        self.death_tick = None  # ticks since Pac-Man was caught (drives the death animation)
        self.tone = None  # PIT divisor to sound during this tick
        self.kill_popup = None  # (screen offset, rows, data) of the points shown at a kill

    # -- views used by the renderer
    @property
    def lives(self): return self.sim.lives
    @property
    def level(self): return self.sim.level
    @property
    def score(self): return self.sim.score_value()
    @property
    def pac_dir(self): return self.sim.dir(0)
    @property
    def pac_frame(self): return self.sim.b(0x2CC9)
    @property
    def pac_offset(self): return self.sim.off(0)
    @property
    def feet(self): return (self.sim.b(0x2CCA) >> 1) & 1
    @property
    def fright_timer(self): return self.sim.b(0x2C9B)
    @property
    def blink(self): return self.sim.b(0x2CCB)
    @property
    def dots_left(self): return self.sim.b(0x2C99)

    @property
    def fruit_state(self): return self.sim.b(0x2F43)

    def cell(self, row, col):
        return self.sim.m[MAZE + row * 30 + col]

    def press(self, direction):
        self.keys.append(direction)

    # -- one BIOS tick
    def tick(self):
        self.events = []
        if self.game_over:
            return
        if self.ready:
            self.ready -= 1
            self.tone = None
            return
        if self.pause:
            if self.clear_tick is not None:
                self.clear_tick += 1
            if self.death_tick is not None:
                t = self.death_tick - DEATH_FREEZE
                n = self.sim.w(0x2CD0 + 2 * t) if 0 <= t < 2 * DEATH_FRAMES else 2  # 0x42F: one note per tick
                self.tone = n if n > 2 else None
                self.death_tick += 1
            elif self.pause > 0 and self.kill_popup is None:
                self.tone = None
            self.pause -= 1
            if self.pause == 0:
                self.kill_popup = None
            if self.pause == 0 and self.after:
                self.after()
                self.after = None
            return
        key = self.keys.popleft() if self.keys else None
        res = self.sim.tick(key)
        self.tone = self.sim.tone
        self.events = list(self.sim.events)
        for e in self.events:
            if isinstance(e, tuple) and e[0] == "ghost":
                self.pause = EAT_PAUSE
                k, idx = e[1], e[2]
                m = self.sim.m
                rows = min(8, (m[ENT + 8] + m[ENT + STRIDE * k + 8]) >> 1)
                di = ((self.sim.off(0) + self.sim.off(k)) >> 1) + 0xA0
                a = 0x25F2 + 0x21 * idx
                self.kill_popup = (di, rows, bytes(m[a : a + 32]))
        if res == "dead":
            self.events.append("dead")
            self.pause = DEATH_PAUSE
            self.death_tick = 0
            self.tone = None
            self.after = self._lose_life
        elif res == "clear":
            self.events.append("clear")
            self.pause = CLEAR_PAUSE
            self.clear_tick = 0
            self.tone = None
            self.after = self._next_level

    def _next_level(self):
        self.clear_tick = None
        self.sim.start_level()
        self.keys.clear()
        self.ready = READY_TICKS

    def _lose_life(self):
        self.death_tick = None
        self.sim.lives -= 1
        if self.sim.lives <= 0:
            self.game_over = True
        else:
            self.sim.sb(0x2F44, 1)  # 0x4D1: only a death resets the fruit (a cleared level keeps it)
            self.sim.sb(0x2F43, 0)
            self.sim.start_life()
            self.keys.clear()
            self.ready = READY_TICKS
