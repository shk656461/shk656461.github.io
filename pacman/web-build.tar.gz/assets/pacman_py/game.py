"""Game wrapper around the literal port of the original's logic (see orig.py)."""

from collections import deque

from .orig import ENT, MAZE, STRIDE, Sim

UP, DOWN, LEFT, RIGHT = 0, 1, 2, 3
COLS, ROWS = 30, 25
WALL, EMPTY, DOT, PELLET = 0, 1, 2, 3
TICK_SECONDS = 65536 / 1193182 * 1.0 * 1  # BIOS timer: 18.2065 Hz
EAT_PAUSE = 3      # the original's 0.44 s wait is its 24-note kill jingle; no sound here, so much shorter
DEATH_PAUSE = 30
CLEAR_PAUSE = 40


class Ghost:
    def __init__(self, sim, k):
        self.sim, self.k = sim, k

    @property
    def direction(self): return self.sim.dir(self.k)
    @property
    def v(self): return self.sim.v(self.k)
    @property
    def h(self): return self.sim.h(self.k)
    @property
    def mode(self): return self.sim.mode(self.k)
    @property
    def offset(self): return self.sim.off(self.k)


class Game:
    def __init__(self):
        self.sim = Sim()
        self.keys = deque(maxlen=4)
        self.pause = 0
        self.after = None
        self.game_over = False
        self.ghosts = [Ghost(self.sim, k) for k in range(1, 5)]
        self.events = []
        self.kill_popup = None  # (screen offset, rows, data) of the points shown at a kill

    # -- views used by the renderer
    @property
    def lives(self): return self.sim.lives
    @property
    def level(self): return self.sim.level
    @property
    def score(self): return self.sim.score_value()
    @property
    def pac_dir(self): return self.sim.dir(0)
    @property
    def pac_frame(self): return self.sim.b(0x2CC9)
    @property
    def pac_offset(self): return self.sim.off(0)
    @property
    def feet(self): return (self.sim.b(0x2CCA) >> 1) & 1
    @property
    def fright_timer(self): return self.sim.b(0x2C9B)
    @property
    def blink(self): return self.sim.b(0x2CCB)
    @property
    def dots_left(self): return self.sim.b(0x2C99)

    @property
    def fruit_state(self): return self.sim.b(0x2F43)

    def cell(self, row, col):
        return self.sim.m[MAZE + row * 30 + col]

    def press(self, direction):
        self.keys.append(direction)

    # -- one BIOS tick
    def tick(self):
        self.events = []
        if self.game_over:
            return
        if self.pause:
            self.pause -= 1
            if self.pause == 0:
                self.kill_popup = None
            if self.pause == 0 and self.after:
                self.after()
                self.after = None
            return
        key = self.keys.popleft() if self.keys else None
        res = self.sim.tick(key)
        self.events = list(self.sim.events)
        for e in self.events:
            if isinstance(e, tuple) and e[0] == "ghost":
                self.pause = EAT_PAUSE
                k, idx = e[1], e[2]
                m = self.sim.m
                rows = min(8, (m[ENT + 8] + m[ENT + STRIDE * k + 8]) >> 1)
                di = ((self.sim.off(0) + self.sim.off(k)) >> 1) + 0xA0
                a = 0x25F2 + 0x21 * idx
                self.kill_popup = (di, rows, bytes(m[a : a + 32]))
        if res == "dead":
            self.events.append("dead")
            self.pause = DEATH_PAUSE
            self.after = self._lose_life
        elif res == "clear":
            self.events.append("clear")
            self.pause = CLEAR_PAUSE
            self.after = self.sim.start_level

    def _lose_life(self):
        self.sim.lives -= 1
        if self.sim.lives <= 0:
            self.game_over = True
        else:
            self.sim.start_life()
            self.keys.clear()
