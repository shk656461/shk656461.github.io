"""Square-wave sound for the PC speaker tones of the original (PIT divisor -> frequency, 1193182 Hz clock)."""

from array import array

RATE = 22050
PIT = 1193182
TICK_LEN = 0.06  # a tone lasts one BIOS tick (0.055 s); replaced by the next tick's tone
JINGLE_NOTE = 0.0025  # seconds per note of the 24-note ghost-eaten sweep (original: busy loop of 5130 iterations, CPU-speed dependent)


def square(divisors, seconds_each, volume=0.25, rate=RATE, channels=1):
    """One Sound-ready 16-bit mono buffer: a square wave per divisor, back to back."""
    out = array("h")
    amp = int(32767 * volume)
    n = int(rate * seconds_each)
    for d in divisors:
        half = max(1.0, rate * d / PIT / 2)
        for i in range(n):
            v = amp if int(i / half) % 2 == 0 else -amp
            for _ in range(channels):
                out.append(v)
    return out.tobytes()


class Audio:
    def __init__(self, pygame):
        self.pg = pygame
        self.ok = False
        self.cache = {}
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=RATE, size=-16, channels=1, buffer=512)
            # the browser mixer may ignore the requested format: build samples for what it really runs at
            self.rate, _fmt, self.nch = pygame.mixer.get_init()
            self.tone_ch = pygame.mixer.Channel(0)
            self.fx_ch = pygame.mixer.Channel(1)
            self.ok = True
        except Exception:  # no audio device: stay silent
            pass

    def _sound(self, key, make):
        if key not in self.cache:
            self.cache[key] = self.pg.mixer.Sound(buffer=make())
        return self.cache[key]

    def tone(self, divisor):
        if not self.ok:
            return
        try:
            if divisor:
                self.tone_ch.play(self._sound(divisor, lambda: square([divisor], TICK_LEN, rate=self.rate, channels=self.nch)))
            else:
                self.tone_ch.stop()
        except Exception:  # never let a sound problem stop the game
            self.ok = False

    def jingle(self, divisors):
        """The ghost-eaten sweep (0xCF3: 24 notes); played faster than the original's 0.44 s wait."""
        if self.ok:
            try:
                key = ("j", tuple(divisors))
                self.fx_ch.play(self._sound(key, lambda: square(divisors, JINGLE_NOTE, rate=self.rate, channels=self.nch)))
            except Exception:
                self.ok = False
