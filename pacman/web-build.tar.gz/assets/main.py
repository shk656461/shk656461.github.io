"""pygbag entry point (browser build). Desktop: python -m pacman_py"""

import asyncio

import pygame  # noqa: F401  (pygbag scans main.py imports to preload pygame)

from pacman_py.__main__ import main

asyncio.run(main())
