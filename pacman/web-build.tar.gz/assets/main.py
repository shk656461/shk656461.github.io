"""pygbag entry point (browser build). Desktop: python -m pacman_py"""

import asyncio

from pacman_py.__main__ import main

asyncio.run(main())
